# EVASION TECHNIQUES

## Try 1

Run the above batch script to disable Windows Defender. Might not work with all Windows versions. Much Better script needed.

## Try 2

Tried pickling the codes into byte streams and accessed it again during run time. Windows Defender caught the action and mitigated the steps.

## Try 3

Runtime download of Python using BITSADMIN via CMD into the system and execute the py files. Currently working on this.